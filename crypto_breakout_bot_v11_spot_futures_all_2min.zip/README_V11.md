# Crypto Breakout Bot V11

الإعدادات المستهدفة:
- فحص تلقائي كل 120 ثانية (دقيقتين).
- MAX_COINS=0 = بدون حد اصطناعي على عدد العملات، حسب ما تسمح به واجهات Binance.
- Spot + USD-M Futures.
- Futures يستخدم fapi.binance.com عند توفر الاتصال، لبيانات Open Interest/Funding/Liquidations إن كانت موجودة في الكود.
- لا يحتاج Binance API key لبيانات السوق العامة.
- لا يشمل DEX-only؛ الاعتماد على أسواق Binance المتاحة عبر APIs.
- BTC مسموح.
- العملات المستقرة يمكن استبعادها كأصل وفق فلتر البوت.

ملاحظة: إذا كانت شبكة الجهاز تمنع Binance Futures فستفشل بيانات Futures فقط؛ Spot وTelegram يمكن أن يستمرا حسب الاتصال.
